package tasksaction;

import java.util.List;
import java.util.Map;

import tasks.TasksBundle;

public class CompletionAction implements TasksAction {

	@Override
	public TasksBundle doAction(TasksBundle tasks, Map<String, Object> params) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Map<String, Object> validate(List<String> untrust_params) {
		// TODO Auto-generated method stub
		return null;
	}

}
