package model;

public enum CreditRating {
}
