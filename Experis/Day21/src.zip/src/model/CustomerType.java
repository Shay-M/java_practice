package model;

public enum CustomerType {
}


